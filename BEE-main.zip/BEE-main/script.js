const API_BASE = "http://localhost:5000/hostel";


document.getElementById("studentForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    
    const name = document.getElementById("studentName").value;
    const age = document.getElementById("studentAge").value;
    const course = document.getElementById("studentCourse").value;

    const response = await fetch(`${API_BASE}/students`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, age, course })
    });

    const data = await response.json();
    alert(data.message);
    loadStudents();
});


async function loadStudents() {
    const response = await fetch(`${API_BASE}/students`);
    const students = await response.json();
    const studentList = document.getElementById("studentList");
    studentList.innerHTML = "";
    students.forEach(student => {
        studentList.innerHTML += `<li>${student.id}: ${student.name} (${student.age} yrs, ${student.course})</li>`;
    });
}

document.getElementById("bookingForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const studentId = document.getElementById("bookingStudentId").value;
    const roomNumber = document.getElementById("roomNumber").value;

    const response = await fetch(`${API_BASE}/book`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, roomNumber })
    });

    const data = await response.json();
    alert(data.message);
    loadBookings();
});


async function loadBookings() {
    const response = await fetch(`${API_BASE}/bookings`);
    const bookings = await response.json();
    const bookingList = document.getElementById("bookingList");
    bookingList.innerHTML = "";
    bookings.forEach(booking => {
        bookingList.innerHTML += `<li>Booking ID: ${booking.id} - Student ${booking.studentId}, Room ${booking.roomNumber}</li>`;
    });
}


loadStudents();
loadBookings();
