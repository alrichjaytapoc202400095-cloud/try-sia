const express = require("express");

const app = express();
app.use(express.json());

let students = [];
let bookings = [];


app.post("/hostel/students", (req, res) => {
  const { name, age, course } = req.body;
  if (!name || !age || !course) return res.status(400).json({ message: "All fields required" });

  students.push({ id: students.length + 1, name, age, course });
  res.status(201).json({ message: "Student added successfully", students });
});


app.get("/hostel/students", (req, res) => {
  res.json(students);
});


app.put("/hostel/students/:id", (req, res) => {
  const { id } = req.params;
  const { name, age, course } = req.body;
  const student = students.find((s) => s.id === parseInt(id));

  if (!student) return res.status(404).json({ message: "Student not found" });

  if (name) student.name = name;
  if (age) student.age = age;
  if (course) student.course = course;

  res.json({ message: "Student updated successfully", student });
});


app.delete("/hostel/students/:id", (req, res) => {
  const { id } = req.params;
  const studentIndex = students.findIndex((s) => s.id === parseInt(id));

  if (studentIndex === -1) return res.status(404).json({ message: "Student not found" });

  students.splice(studentIndex, 1);

  res.json({ message: "Student deleted successfully", students });
});

//
app.post('/bookings', (req, res) => {
  const { studentName, roomNumber, duration } = req.body;
  const id = bookings.length + 1;
  const newBooking = { id, studentName, roomNumber, duration };
  bookings.push(newBooking);
  res.status(201).json({ message: 'Room booked successfully', booking: newBooking });
});


app.get('/bookings', (req, res) => {
  res.json(bookings);
});

app.get('/bookings/:id', (req, res) => {
  const booking = bookings.find(b => b.id == req.params.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found' });
  res.json(booking);
});


app.put('/bookings/:id', (req, res) => {
  const booking = bookings.find(b => b.id == req.params.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found' });

  const { studentName, roomNumber, duration } = req.body;
  if (studentName) booking.studentName = studentName;
  if (roomNumber) booking.roomNumber = roomNumber;
  if (duration) booking.duration = duration;

  res.json({ message: 'Booking updated successfully', booking });
});


app.delete('/bookings/:id', (req, res) => {
  const index = bookings.findIndex(b => b.id == req.params.id);
  if (index === -1) return res.status(404).json({ message: 'Booking not found' });

  bookings.splice(index, 1);
  res.json({ message: 'Booking deleted successfully' });
});

//
app.get('/wardens/:id', (req, res) => {
  const warden = wardens.find(w => w.id === parseInt(req.params.id));
  if (!warden) return res.status(404).json({ message: "Warden not found" });
  res.json(warden);
});


app.post('/wardens', (req, res) => {
  const { name, age, contact } = req.body;
  const newWarden = { id: wardens.length + 1, name, age, contact };
  wardens.push(newWarden);
  res.status(201).json(newWarden);
});


app.put('/wardens/:id', (req, res) => {
  const warden = wardens.find(w => w.id === parseInt(req.params.id));
  if (!warden) return res.status(404).json({ message: "Warden not found" });
  
  const { name, age, contact } = req.body;
  if (name) warden.name = name;
  if (age) warden.age = age;
  if (contact) warden.contact = contact;
  
  res.json(warden);
});


app.delete('/wardens/:id', (req, res) => {
  const index = wardens.findIndex(w => w.id === parseInt(req.params.id));
  if (index === -1) return res.status(404).json({ message: "Warden not found" });
  
  wardens.splice(index, 1);
  res.json({ message: "Warden deleted successfully" });
});

//
app.get('/workers', (req, res) => {
  res.json(workers);
});

app.get('/workers/:id', (req, res) => {
  const worker = workers.find(w => w.id === parseInt(req.params.id));
  if (worker) {
      res.json(worker);
  } else {
      res.status(404).json({ message: 'Worker not found' });
  }
});

app.post('/workers', (req, res) => {
  const newWorker = { id: workers.length + 1, ...req.body };
  workers.push(newWorker);
  res.status(201).json(newWorker);
});


const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
